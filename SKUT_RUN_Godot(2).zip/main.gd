extends Node3D

# SKUT RUN - prototipo 3D inicial para Godot 4
# Controles táctiles: tocar = saltar; deslizar izquierda/derecha = cambiar carril.

const LANES := [-2.2, 0.0, 2.2]
const PLAYER_Z := 5.0
const SPAWN_Z := -38.0
const DESPAWN_Z := 12.0

var lane := 1
var target_x := 0.0
var vertical_velocity := 0.0
var is_jumping := false
var speed := 17.0
var score := 0
var coins := 0
var game_over := false
var spawn_timer := 0.0
var coin_timer := 0.0
var touch_start := Vector2.ZERO

var player: Node3D
var world_items: Array[Node3D] = []
var score_label: Label
var coin_label: Label
var message_label: Label
var restart_button: Button

func _ready() -> void:
	_build_world()
	_build_player()
	_build_ui()
	_spawn_initial_items()

func _process(delta: float) -> void:
	if game_over:
		return
	speed = minf(speed + delta * 0.12, 29.0)
	score += int(delta * speed)
	score_label.text = "DISTANCIA: %d" % score
	coin_label.text = "🟡 %d" % coins

	# Movimiento lateral suave entre tres carriles.
	player.position.x = move_toward(player.position.x, LANES[lane], delta * 12.0)

	# Salto con gravedad.
	if is_jumping:
		vertical_velocity -= 25.0 * delta
		player.position.y += vertical_velocity * delta
		if player.position.y <= 0.0:
			player.position.y = 0.0
			is_jumping = false
			vertical_velocity = 0.0

	# El escenario y los objetos avanzan hacia el jugador.
	for item in world_items.duplicate():
		item.position.z += speed * delta
		if item.position.z > DESPAWN_Z:
			world_items.erase(item)
			item.queue_free()
		elif item.has_meta("obstacle") and item.position.z > 4.1 and item.position.z < 5.9:
			if absf(item.position.x - player.position.x) < 0.85 and player.position.y < 1.0:
				_end_game()
		elif item.has_meta("coin") and item.position.z > 4.0 and item.position.z < 5.8:
			if absf(item.position.x - player.position.x) < 0.9:
				coins += 1
				world_items.erase(item)
				item.queue_free()

	spawn_timer -= delta
	coin_timer -= delta
	if spawn_timer <= 0.0:
		_spawn_obstacle()
		spawn_timer = randf_range(0.85, 1.35)
	if coin_timer <= 0.0:
		_spawn_coin_line()
		coin_timer = randf_range(1.8, 2.8)

func _input(event: InputEvent) -> void:
	if game_over:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_start = event.position
		else:
			var diff := event.position - touch_start
			if diff.length() < 35.0:
				_jump()
			elif absf(diff.x) > absf(diff.y):
				if diff.x > 0:
					_change_lane(1)
				else:
					_change_lane(-1)
			elif diff.y < 0:
				_jump()
	elif event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_LEFT, KEY_A: _change_lane(-1)
			KEY_RIGHT, KEY_D: _change_lane(1)
			KEY_SPACE, KEY_UP: _jump()

func _change_lane(direction: int) -> void:
	lane = clampi(lane + direction, 0, 2)

func _jump() -> void:
	if not is_jumping:
		is_jumping = true
		vertical_velocity = 10.5

func _build_world() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.48, 0.68, 0.82)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.8, 0.82, 0.9)
	env.ambient_light_energy = 0.8
	environment.environment = env
	add_child(environment)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -25, 0)
	sun.light_energy = 1.25
	add_child(sun)

	var camera := Camera3D.new()
	camera.position = Vector3(0, 5.2, 11.5)
	camera.rotation_degrees = Vector3(-15, 0, 0)
	camera.current = true
	add_child(camera)

	_make_box("Asfalto", Vector3(7.2, 0.2, 100.0), Vector3(0, -0.12, -35), Color(0.12, 0.13, 0.15))
	_make_box("Vereda izquierda", Vector3(2.0, 0.35, 100.0), Vector3(-4.6, 0, -35), Color(0.48, 0.48, 0.45))
	_make_box("Vereda derecha", Vector3(2.0, 0.35, 100.0), Vector3(4.6, 0, -35), Color(0.48, 0.48, 0.45))
	for z in range(-85, 15, 8):
		_make_box("Línea carril", Vector3(0.08, 0.025, 3.0), Vector3(-1.1, 0.0, z), Color(0.92, 0.88, 0.65))
		_make_box("Línea carril", Vector3(0.08, 0.025, 3.0), Vector3(1.1, 0.0, z), Color(0.92, 0.88, 0.65))
	# Edificios sencillos que dan ambiente de ciudad.
	for side in [-1, 1]:
		for i in range(10):
			var h := randf_range(5.0, 13.0)
			var w := randf_range(2.5, 4.0)
			var b := _make_box("Edificio", Vector3(w, h, 5.0), Vector3(side * randf_range(7.0, 10.0), h / 2.0, -i * 10.0 - 10), Color(0.48 + randf() * 0.18, 0.42 + randf() * 0.16, 0.38 + randf() * 0.18))
			b.position.x = side * (6.8 + w / 2.0)

func _build_player() -> void:
	player = Node3D.new()
	player.position = Vector3(0, 0, PLAYER_Z)
	add_child(player)

	# Cuerpo urbano: polerón oscuro, pantalón y zapatillas.
	_make_player_box(player, Vector3(0, 1.15, 0), Vector3(0.75, 0.9, 0.42), Color(0.12, 0.12, 0.16))
	_make_player_box(player, Vector3(0, 1.85, 0), Vector3(0.62, 0.55, 0.55), Color(0.08, 0.08, 0.11))
	_make_player_box(player, Vector3(-0.2, 0.42, 0), Vector3(0.25, 0.75, 0.3), Color(0.08, 0.09, 0.12))
	_make_player_box(player, Vector3(0.2, 0.42, 0), Vector3(0.25, 0.75, 0.3), Color(0.08, 0.09, 0.12))
	_make_player_box(player, Vector3(-0.2, 0.12, -0.08), Vector3(0.32, 0.18, 0.48), Color(0.92, 0.92, 0.92))
	_make_player_box(player, Vector3(0.2, 0.12, -0.08), Vector3(0.32, 0.18, 0.48), Color(0.92, 0.92, 0.92))
	_make_player_box(player, Vector3(0, 2.25, 0), Vector3(0.48, 0.48, 0.48), Color(0.68, 0.43, 0.29))

func _make_player_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
	var mesh_node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mesh_node.material_override = mat
	parent.add_child(mesh_node)

func _make_box(label: String, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.name = label
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	node.material_override = mat
	add_child(node)
	return node

func _spawn_obstacle() -> void:
	var obstacle := _make_box("Obstáculo", Vector3(1.25, 1.25, 0.8), Vector3(LANES[randi_range(0, 2)], 0.65, SPAWN_Z), Color(0.8, 0.22, 0.12))
	obstacle.set_meta("obstacle", true)
	world_items.append(obstacle)

func _spawn_coin_line() -> void:
	var chosen_lane := LANES[randi_range(0, 2)]
	for i in range(4):
		var coin := MeshInstance3D.new()
		coin.name = "Moneda"
		var mesh := CylinderMesh.new()
		mesh.top_radius = 0.38
		mesh.bottom_radius = 0.38
		mesh.height = 0.12
		coin.mesh = mesh
		coin.rotation_degrees.x = 90
		coin.position = Vector3(chosen_lane, 1.25, SPAWN_Z - i * 1.7)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(1.0, 0.72, 0.05)
		mat.metallic = 0.65
		coin.material_override = mat
		add_child(coin)
		coin.set_meta("coin", true)
		world_items.append(coin)

func _spawn_initial_items() -> void:
	_spawn_coin_line()
	_spawn_obstacle()

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := ColorRect.new()
	panel.position = Vector2(12, 12)
	panel.size = Vector2(330, 105)
	panel.color = Color(0.02, 0.02, 0.03, 0.68)
	layer.add_child(panel)

	score_label = Label.new()
	score_label.position = Vector2(28, 20)
	score_label.add_theme_font_size_override("font_size", 25)
	score_label.text = "DISTANCIA: 0"
	layer.add_child(score_label)

	coin_label = Label.new()
	coin_label.position = Vector2(28, 58)
	coin_label.add_theme_font_size_override("font_size", 24)
	coin_label.text = "🟡 0"
	layer.add_child(coin_label)

	var hint := Label.new()
	hint.anchor_left = 0.0
	hint.anchor_right = 1.0
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_left = 10
	hint.offset_top = -62
	hint.offset_right = -10
	hint.offset_bottom = -12
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.text = "TOCA: SALTAR     DESLIZA: CAMBIAR DE CARRIL"
	hint.add_theme_font_size_override("font_size", 17)
	hint.add_theme_color_override("font_color", Color.WHITE)
	layer.add_child(hint)

	message_label = Label.new()
	message_label.anchor_left = 0.0
	message_label.anchor_right = 1.0
	message_label.anchor_top = 0.4
	message_label.anchor_bottom = 0.4
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 42)
	message_label.add_theme_color_override("font_color", Color.WHITE)
	layer.add_child(message_label)

	restart_button = Button.new()
	restart_button.text = "VOLVER A JUGAR"
	restart_button.anchor_left = 0.5
	restart_button.anchor_right = 0.5
	restart_button.anchor_top = 0.55
	restart_button.anchor_bottom = 0.55
	restart_button.offset_left = -110
	restart_button.offset_right = 110
	restart_button.offset_top = 0
	restart_button.offset_bottom = 58
	restart_button.visible = false
	restart_button.pressed.connect(_restart)
	layer.add_child(restart_button)

func _end_game() -> void:
	game_over = true
	message_label.text = "¡FIN DEL JUEGO!"
	restart_button.visible = true

func _restart() -> void:
	get_tree().reload_current_scene()
